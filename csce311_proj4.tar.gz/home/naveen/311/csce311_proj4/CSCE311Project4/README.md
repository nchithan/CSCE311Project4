# CSCE311Project4

The different files are text-client.cc and text-server.cc and shared.h. The makefile allows you to compile and run the programs easily.

To run the code you run make text-server and make text-client. From there ./text-server to run server file. And ./text-client dat/dante.txt for client file.
